import React from 'react';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { useGetUsersQuery, useCreateUserMutation } from '../api';
import Login from '../components/Login';
import Signup from '../components/Signup';

// Mock the useGetUsersQuery hook
jest.mock('../api', () => ({
    useGetUsersQuery: jest.fn(),
    useCreateUserMutation: jest.fn(),
}));

test('renders email and password input fields and login button', () => {
    // Provide a mock response for the useGetUsersQuery hook
    useGetUsersQuery.mockReturnValue({ data: [], isLoading: false, refetch: jest.fn() });

    render(
        <MemoryRouter>
            <Login />
        </MemoryRouter>
    );

    const emailInput = screen.getByLabelText('Email Address');
    const passwordInput = screen.getByLabelText('Password');
    const loginButton = screen.getByRole('button', { name: 'Login' });
    expect(emailInput).toBeInTheDocument();
    expect(passwordInput).toBeInTheDocument();
    expect(loginButton).toBeInTheDocument();

});



test('renders labels and input fields for Signup component', () => {
    // Provide a mock response for the useGetUsersQuery hook
    useGetUsersQuery.mockReturnValue({ data: [], isLoading: false, refetch: jest.fn() });

    // Provide a mock response for the useCreateUserMutation hook
    useCreateUserMutation.mockReturnValue([jest.fn(), { data: null, isLoading: false, error: null }]);

    render(
        <MemoryRouter>
            <Signup />
        </MemoryRouter>
    );

    // Test whether the labels and input fields are visible
    const nameLabel = screen.getByLabelText('Name');
    const emailLabel = screen.getByLabelText('Email');
    const passwordLabel = screen.getByLabelText('Password');
    const roleLabel = screen.getByLabelText('Role');
    const statusLabel = screen.getByLabelText('Status');

    expect(nameLabel).toBeInTheDocument();
    expect(emailLabel).toBeInTheDocument();
    expect(passwordLabel).toBeInTheDocument();
    expect(roleLabel).toBeInTheDocument();
    expect(statusLabel).toBeInTheDocument();

});




