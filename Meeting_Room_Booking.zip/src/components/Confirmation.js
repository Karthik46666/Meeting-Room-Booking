import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { NotificationManager } from 'react-notifications';


const Confirmation = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const booking = location.state?.booking;

    const handleLogout = () => {
        navigate(`/`);
        NotificationManager.success('Booking Done Successfully');

    };

    return (
        <div>
            {booking && (
                <div className='container p-4 card'>
                    <h2>YOUR BOOKING</h2>
                    <p>Room Name: {booking.roomname}</p>
                    <p>Date of Booking: {booking.date}</p>
                    <p>Total Amount: {booking.total}</p>
                    <p>Duration: {booking.duration}</p>
                    <h2>BILLING DETAILS</h2>

                    {booking.client.map((client, index) => (
                        <div key={index}>
                            <p>Name: {client.name}</p>
                            <p>Phone: {client.phone}</p>
                            <p>Email: {client.email},</p>
                            <p>paymentMethod: {client.paymentMethod}</p>
                            <p>Address: {client.address}</p>
                        </div>
                    ))}
                    <button type="submit" class="btn btn-primary m-2 col-2" onClick={handleLogout}>
                        Confirm
                    </button>
                </div>
            )}
        </div>
    );
};

export default Confirmation;
