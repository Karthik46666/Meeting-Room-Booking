import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { NotificationManager } from 'react-notifications';
import { useGetBookingByIdQuery, useUpdateBookingMutation, useGetBookingsQuery } from '../api';

const EditBooking = () => {
    const { bookingId } = useParams();
    const navigate = useNavigate();
    const { data: booking, isLoading, isError } = useGetBookingByIdQuery(bookingId);
    const { refetch } = useGetBookingsQuery();
    const [formData, setFormData] = useState({
        roomname: '',
        date: '',
        name: '',
        total: '',
        status: '',
        paymentmethod: '',
        duration: '',
        roomprice: '',
        tax: '',
    });
    const [updateBooking, { isLoading: isUpdating }] = useUpdateBookingMutation();

    useEffect(() => {
        if (booking) {
            const clientName = booking.client && booking.client.length > 0 ? booking.client[0].name : '';
            setFormData((prevFormData) => ({
                ...prevFormData,
                roomname: booking.roomname,
                date: booking.date,
                name: clientName,
                total: booking.total,
                status: booking.status,
                paymentmethod: booking.paymentmethod,
                duration: booking.duration,
                roomprice: booking.roomprice,
                tax: booking.tax,
            }));
        }
    }, [booking]);

    const handleInputChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        // Get the client name from the form data
        const clientName = formData.name;
        // Update the booking data
        const updatedBooking = {
            id: bookingId,
            ...formData,
            client: [{ name: clientName }],
        };
        await updateBooking(updatedBooking).unwrap();
        refetch();
        NotificationManager.success('Updated Booking Successfully');
        navigate('/booking');
    };

    if (isLoading) {
        return <div>Loading...</div>;
    }

    if (isError) {
        return <div>Error occurred while fetching booking data.</div>;
    }

    // Get today's date
    const today = new Date().toISOString().split('T')[0];

    return (
        <div className='container-fluid'>

            <div className='row'>
                <div className="col-2 sidebar">

                    <span className="side-mouse" ><i className="fa fa-clock-o p-2" aria-hidden="true"></i> <p className="p-1">Dashboard</p></span>
                    <span className="side-mouse" onClick={() => navigate('/booking')}><i className="fa fa-file-o p-2" aria-hidden="true"></i> <p className="p-1">Bookings</p></span>
                    <span className="side-mouse" ><i className="fa fa-square-o p-2" aria-hidden="true"></i> <p className="p-1" >Rooms</p></span>
                    <span className="side-mouse" onClick={() => navigate('/admin-user')}><i className="fa fa-users p-2" aria-hidden="true"></i> <p className="p-1" >Users</p></span>
                    <span className="side-mouse" onClick={() => navigate('/')}><i className="fa fa-sign-out p-2" aria-hidden="true"></i> <p className="p-1" >Logout</p></span>
                </div>
                <div className="col-10">
                    <h1>Edit Booking</h1>
                    <form onSubmit={handleSubmit}>
                        <div>
                            <label for="exampleInputEmail1" class="form-label">Room Name</label>
                            <select
                                className="form-select"
                                id="roomname"
                                name="roomname"
                                value={formData.roomname}
                                onChange={handleInputChange}
                            >
                                <option value="Small Conference Room">Small Conference Room</option>
                                <option value="Large Conference Room">Large Conference Room</option>
                                <option value="Panoramic Room">Panoramic Room</option>
                            </select>
                        </div>

                        <div>
                            <label for="exampleInputEmail1" class="form-label">Date</label>
                            <input
                                type="date"
                                className="form-control"
                                id="date"
                                name="date"
                                value={formData.date}
                                min={today} // Set the minimum date to today
                                onChange={handleInputChange}
                            />
                        </div>

                        <div>
                            <label for="exampleInputEmail1" class="form-label">Name</label>
                            <input
                                className="form-control"
                                type="text"
                                id="name"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                            />
                        </div>

                        <div>
                            <label for="exampleInputEmail1" class="form-label">Total</label>
                            <input
                                className="form-control"
                                type="text"
                                id="total"
                                name="total"
                                value={formData.total}
                                onChange={handleInputChange}
                            />
                        </div>

                        <div>
                            <label for="exampleInputEmail1" class="form-label">Status</label>
                            <select
                                className="form-select"
                                id="status"
                                name="status"
                                value={formData.status}
                                onChange={handleInputChange}
                            >
                                <option value="Pending">Pending</option>
                                <option value="Confirmed">Confirmed</option>
                                <option value="Cancelled">Cancelled</option>
                            </select>
                        </div>

                        {/* Add other form fields here */}
                        <button type="submit" className="btn btn-primary mt-2" disabled={isUpdating}>
                            {isUpdating ? 'Updateing...' : 'Update'}
                        </button>

                    </form>
                </div>
            </div>
        </div>
    );
};

export default EditBooking;
