import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGetBookingsQuery } from '../api';
import 'font-awesome/css/font-awesome.min.css';
import "../App.css";


const Dashboard = () => {
    const { data: bookings = [], isLoading } = useGetBookingsQuery();
    const navigate = useNavigate();
    //Total Booking
    const totalBookings = bookings.length;
    //Latest Booking
    const lastBooking = bookings.length > 0 ? bookings[bookings.length - 1] : null;
    //Reservation
    const [selectedDate, setSelectedDate] = useState('');
    const [selectedBooking, setSelectedBooking] = useState(null);
    const handleDateChange = (e) => {
        const selectedDate = e.target.value;
        setSelectedDate(selectedDate);

        // Find the booking for the selected date
        const booking = bookings.find((booking) => booking.date === selectedDate);
        setSelectedBooking(booking || null);
    };

    //Getting length of Today date booking
    const [todaysBookings, setTodaysBookings] = useState([]);
    useEffect(() => {
        const today = new Date().toISOString().split('T')[0]; // Get today's date in YYYY-MM-DD format
        const filteredBookings = bookings.filter((booking) => booking.date === today);
        setTodaysBookings(filteredBookings);
    }, [bookings]);
    console.log(todaysBookings, "hi")

    if (isLoading) {
        return <div>Loading...</div>;
    }

    const handleCreateRoom = () => {
        navigate(`/rooms`);
    };
    return (
        <>
            <div className='container-fluid'>
                <div className='row'>
                    <div className="col-2 sidebar">

                        <span className="side-mouse" ><i className="fa fa-clock-o p-2" aria-hidden="true"></i> <p className="p-1">Dashboard</p></span>
                        <span className="side-mouse" onClick={() => navigate('/booking')}><i className="fa fa-file-o p-2" aria-hidden="true"></i> <p className="p-1">Bookings</p></span>
                        <span className="side-mouse" onClick={() => handleCreateRoom()}><i className="fa fa-square-o p-2" aria-hidden="true"></i> <p className="p-1" >Rooms</p></span>
                        <span className="side-mouse" onClick={() => navigate('/admin-user')}><i className="fa fa-users p-2" aria-hidden="true"></i> <p className="p-1" >Users</p></span>
                        <span className="side-mouse" onClick={() => navigate('/')}><i className="fa fa-sign-out p-2" aria-hidden="true"></i> <p className="p-1" >Logout</p></span>
                    </div>
                    <div className="col-10">

                        <div className='card dashboard-card'>
                            <div className='card-body'>
                                <div className='row'>
                                    <div className='col-4'>
                                        <i className="fa fa-file p-2 file-icon" style={{ "font-size": 30 }} aria-hidden="true">
                                            <span className="booking-title p-2">{todaysBookings.length}</span>
                                        </i>
                                        <span className="booking-title">Booking made today</span>
                                    </div>
                                    <div className='col-4'>
                                        <i className="fa fa-file p-2 file-icon" style={{ "font-size": 30 }} aria-hidden="true">
                                            <span className="booking-title p-2">{todaysBookings.length}</span>
                                        </i>
                                        <span className="booking-title">Booking for today</span>
                                    </div>
                                    <div className='col-4'>
                                        <i className="fa fa-file p-2 file-icon" style={{ "font-size": 30 }} aria-hidden="true">
                                            <span className="booking-title p-2"> {totalBookings}</span>
                                        </i>
                                        <span className="booking-title">Total Booking made</span>
                                    </div>

                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-4 mt-3">
                                {lastBooking ? (
                                    <div class="card">
                                        <h5 class="card-header">Latest bookings</h5>
                                        <div class="card-body">
                                            <p class="card-text">{lastBooking.roomname}</p>
                                            <p class="card-text">Date:{lastBooking.date}</p>
                                            <p class="card-text dashboard-color">{lastBooking.name}</p>
                                        </div>
                                    </div>
                                ) : (
                                    <p>No bookings found.</p>
                                )}
                            </div>
                            <div class="col-4 mt-3">
                                <div class="card">
                                    <h5 class="card-header">Reservations</h5>
                                    <div class="card-body">
                                        <div className="mb-3">
                                            <label htmlFor="datepicker" className="form-label">
                                                Select a Date:
                                            </label>
                                            <input
                                                type="date"
                                                id="datepicker"
                                                className="form-control"
                                                value={selectedDate}
                                                onChange={handleDateChange}
                                            />
                                        </div>
                                        {selectedBooking ? (
                                            <div className="card">
                                                <div className="card-body">
                                                    <h5 className="card-title">Booking Details</h5>
                                                    <p className="card-text">Room Name: {selectedBooking.roomname}</p>
                                                    <p className="card-text">Name: {selectedBooking.client[0].name}</p>
                                                </div>
                                            </div>
                                        ) : (
                                            <p>No booking found for the selected date.</p>
                                        )}
                                        {/* <p class="card-text">small conference room</p> */}
                                    </div>
                                </div>
                            </div>
                            <div class="col-4 mt-3">
                                <div class="card">
                                    <h5 class="card-header">Quick links</h5>
                                    <div class="card-body">
                                        <p class="card-text links" onClick={() => navigate('/add-booking')}>+ Add bookings</p>
                                        <p class="card-text links" onClick={() => navigate('/add-room')}>+ Add room</p>
                                        <p class="card-text links" onClick={() => navigate('/booking')}>View Bookings</p>
                                        <p class="card-text links" onClick={() => navigate('/rooms')}>View Rooms</p>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </>
    );
};

export default Dashboard;
