import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useGetRoomsQuery, useCreateBookingMutation, useGetBookingsQuery } from '../api';

import "../App.css";

const UserRoomBooking = () => {
    const [showClientForm, setShowClientForm] = useState(false);
    const navigate = useNavigate();
    const { refetch } = useGetBookingsQuery
    const { roomId } = useParams();
    const { data: rooms = [], isLoading } = useGetRoomsQuery();
    const [date, setDate] = useState('');
    const [attendees, setAttendees] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('');
    const [duration, setDuration] = useState('');
    const [selectedDays, setSelectedDays] = useState([]);
    const [selectedHalfDay, setSelectedHalfDay] = useState('');
    const [selectedHour, setSelectedHour] = useState('');

    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [address, setAddress] = useState('');


    const [createBooking] = useCreateBookingMutation();




    if (isLoading) {
        return <div>Loading...</div>;
    }

    const room = rooms.find((room) => room.id === parseInt(roomId));

    if (!room) {
        return <div>Room not found</div>;
    }


    // const handleDurationButtonClick = async (duration) => {
    //     setDuration(duration);
    // };

    const handleSaveBooking = async () => {
        const clientData = {
            name,
            phone,
            email,
            paymentMethod,
            address,
        };

        //1st page
        let selectedDuration = duration;
        if (selectedDays.length === 1) {
            const selectedDay = selectedDays[0];
            if (selectedDay === 'Monday' || selectedDay === 'Tuesday' || selectedDay === 'Wednesday' || selectedDay === 'Saturday') {
                selectedDuration = 'Multiple Days';
            }
        }
        const bookingData = {
            roomId,
            roomname: room.room,
            status: room.status,
            total: room.priceperday,
            date,
            attendees,
            duration: selectedDuration,
            client: [clientData],
        };
        if (duration === 'multipledays') {
            bookingData.duration = selectedDays.join(','); // Update duration with selected days
        } else if (duration === 'halfday') {
            bookingData.duration = selectedHalfDay; // Update duration with selected half day
        } else if (duration === 'hours') {
            bookingData.duration = selectedHour; // Update duration with selected hour
        }



        try {
            const response = await createBooking(bookingData).unwrap();
            console.log('Booking created:', response);
            const updatedBookings = await fetch('http://localhost:3001/bookings').then((res) => res.json());
            navigate('/confirmation', { state: { booking: response } }); // Navigate to confirmation page with booking data
            refetch();
            console.log('Updated bookings data:', updatedBookings);
        } catch (error) {
            console.error('Error creating booking:', error);
        }
    };

    const handleDayButtonClick = (day, e) => {
        e.preventDefault();
        if (selectedDays.includes(day)) {
            setSelectedDays(selectedDays.filter((selectedDay) => selectedDay !== day));
        } else {
            setSelectedDays([...selectedDays, day]);
        }
        setDuration('multipledays'); // Update duration to 'multipledays'
    };


    const handleHalfDayButtonClick = (halfDay, e) => {
        e.preventDefault();
        setSelectedHalfDay(halfDay);
        setDuration('halfday'); // Update duration to 'halfday'
    };

    const handleHourButtonClick = (hour, e) => {
        e.preventDefault();
        setSelectedHour(hour);
        setDuration('hours'); // Update duration to 'hours'
    };

    // Get today's date
    const today = new Date().toISOString().split('T')[0];
    const handleNextClick = () => {
        setShowClientForm(true);
    };

    return (
        <>
            <div className='container-fluid p-0'>
                <div className="header">
                    <p className="fs-2 mb-0 fw-bold">Meeting rooms</p>
                    <Link to="/" className="d-flex align-items-center  px-0 text-dark text-decoration-none fs-5 fw-bold">
                        <i className="fa fa-sign-out"></i> <span className="ms-3 d-none d-sm-inline">Logout</span>
                    </Link>
                </div>
                <div className="card m-5 p-4">

                    <h2>User Room Booking</h2>
                    <div className='row'>


                        <div className='col-6'>
                            <img src={room.image} alt={room.room} width={"400px"} />
                            <p>Price per Day: {room.priceperday}</p>
                            <p>Price per Hour: {room.priceperhour}</p>
                        </div>
                        <div className='col-6'>
                            {!showClientForm ? (
                                <div>
                                    <p class="form-label" style={{ fontWeight: 'bold', fontSize: 20 }}>{room.room}</p>
                                    <p class="form-label">Capacity: {room.capacity}</p>
                                    <div className="mb-3">
                                        <label htmlFor="dateInput" className="form-label">Date</label>
                                        <input type="date" id="dateInput" className="form-control" min={today} value={date} onChange={(e) => setDate(e.target.value)} />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="durationSelect" className="form-label">Duration</label>
                                        <select className="form-select" id="durationSelect" value={duration} onChange={(e) => setDuration(e.target.value)}>
                                            <option value="">Select Duration</option>
                                            <option value="multipledays">Multiple Days</option>
                                            <option value="halfday">Half Day</option>
                                            <option value="hours">Hours</option>
                                        </select>
                                    </div>
                                    {duration === 'multipledays' && (
                                        <div className="mb-3">
                                            <p>Select days:</p>
                                            <button
                                                onClick={(e) => handleDayButtonClick('Monday', e)} className={selectedDays.includes('Monday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Monday</button>
                                            <button
                                                onClick={(e) => handleDayButtonClick('Tuesday', e)}
                                                className={selectedDays.includes('Tuesday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Tuesday</button>
                                            <button onClick={(e) => handleDayButtonClick('Wednesday', e)}
                                                className={selectedDays.includes('Wednesday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Wednesday</button>
                                            <button onClick={(e) => handleDayButtonClick('Thursday', e)}
                                                className={selectedDays.includes('Thursday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Thursday</button>
                                            <button onClick={(e) => handleDayButtonClick('Friday', e)}
                                                className={selectedDays.includes('Friday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Friday</button>
                                            <button onClick={(e) => handleDayButtonClick('Saturday', e)}
                                                className={selectedDays.includes('Saturday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Saturday</button>
                                        </div>
                                    )}
                                    {duration === 'halfday' && (
                                        <div className="mb-3">
                                            <p>Select half day:</p>
                                            <button onClick={(e) => handleHalfDayButtonClick('Morning', e)}
                                                className={selectedHalfDay === 'Morning' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Morning (08:00-12:00)</button>
                                            <button onClick={(e) => handleHalfDayButtonClick('Afternoon', e)}
                                                className={selectedHalfDay === 'Afternoon' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Afternoon (13:00-16:00)</button>
                                            <button onClick={(e) => handleHalfDayButtonClick('Evening', e)}
                                                className={selectedHalfDay === 'Evening' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'} >Evening (16:00-18:00)</button>
                                        </div>
                                    )}
                                    {duration === 'hours' && (
                                        <div className="mb-3">
                                            <p>Select hours:</p>
                                            <button onClick={(e) => handleHourButtonClick('09:00-10:00', e)}
                                                className={selectedHour === '09:00-10:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>09:00-10:00</button>
                                            <button onClick={(e) => handleHourButtonClick('10:00-11:00', e)}
                                                className={selectedHour === '10:00-11:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>10:00-11:00</button>
                                            <button onClick={(e) => handleHourButtonClick('11:00-12:00', e)}
                                                className={selectedHour === '11:00-12:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>11:00-12:00</button>
                                            <button onClick={(e) => handleHourButtonClick('12:00-13:00', e)}
                                                className={selectedHour === '12:00-13:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>12:00-13:00</button>
                                            <button onClick={(e) => handleHourButtonClick('13:00-14:00', e)}
                                                className={selectedHour === '13:00-14:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>13:00-14:00</button>
                                            <button onClick={(e) => handleHourButtonClick('14:00-15:00', e)}
                                                className={selectedHour === '14:00-15:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>14:00-15:00</button>
                                            <button onClick={(e) => handleHourButtonClick('15:00-16:00', e)}
                                                className={selectedHour === '15:00-16:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>15:00-16:00</button>
                                            <button onClick={(e) => handleHourButtonClick('16:00-17:00', e)}
                                                className={selectedHour === '16:00-17:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>16:00-17:00</button>
                                            <button onClick={(e) => handleHourButtonClick('17:00-18:00', e)}
                                                className={selectedHour === '17:00-18:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>17:00-18:00</button>
                                        </div>
                                    )}
                                    {/* {duration && (
                                        <div className="mb-3">
                                            <p>Selected Duration: {duration}</p>
                                        </div>
                                    )} */}
                                    <div className="mb-3">
                                        <label htmlFor="attendees" className="form-label">Attendees</label>
                                        <input type="number" className="form-control" id="attendees" value={attendees} onChange={(e) => setAttendees(e.target.value)} />
                                    </div>

                                    <button type="button" className="btn btn-primary" onClick={handleNextClick}>Next</button>
                                </div>
                            ) : (



                                <div>
                                    <h2>Billing Details</h2>

                                    <div className="mb-3">
                                        <label htmlFor="nameInput" className="form-label">Name</label>
                                        <input type="text" className="form-control" id="nameInput" value={name} onChange={(e) => setName(e.target.value)} />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="phoneInput" className="form-label">Phone</label>
                                        <input type="number" className="form-control" id="phoneInput" value={phone} onChange={(e) => setPhone(e.target.value)} />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="emailInput" className="form-label">Email</label>
                                        <input type="email" className="form-control" id="emailInput" value={email} onChange={(e) => setEmail(e.target.value)} />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="paymentMethod" className="form-label">Payment Method:</label>
                                        <select id="paymentMethod" className="form-select" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)} required>
                                            <option value="">Select Payment Method</option>
                                            <option value="Card">Card</option>
                                            <option value="Cash">Cash</option>
                                        </select>
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="addressInput" className="form-label">Address</label>
                                        <input type="text" className="form-control" id="addressInput" value={address} onChange={(e) => setAddress(e.target.value)} />
                                    </div>

                                    <button type="button" className="btn btn-primary" onClick={handleSaveBooking}>Save</button>
                                </div>

                            )}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default UserRoomBooking;
