import React, { useState } from 'react';
import { useCreateBookingMutation, useGetBookingsQuery } from '../api';
import { useNavigate } from 'react-router-dom';
import { NotificationManager } from 'react-notifications';


const AddBooking = () => {
    const navigate = useNavigate();
    const [roomname, setRoomname] = useState('');
    const [date, setDate] = useState('');
    const [total, setTotal] = useState('');
    const [status, setStatus] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('');
    const [duration, setDuration] = useState('');
    const [selectedDays, setSelectedDays] = useState([]);
    const [selectedHalfDay, setSelectedHalfDay] = useState('');
    const [selectedHour, setSelectedHour] = useState('');
    const [roomPrice, setRoomPrice] = useState('');
    const [tax, setTax] = useState('');
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [companyName, setCompanyName] = useState('');
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('');

    const [createBooking] = useCreateBookingMutation();
    const { refetch } = useGetBookingsQuery();


    const handleSaveBooking = (e) => {
        e.preventDefault();
        //Duration Functionality
        let selectedDuration = duration;
        if (selectedDays.length === 1) {
            const selectedDay = selectedDays[0];
            if (selectedDay === 'Monday' || selectedDay === 'Tuesday' || selectedDay === 'Wednesday' || selectedDay === 'Saturday') {
                selectedDuration = 'Multiple Days';
            }
        }

        const bookingData = {
            roomname,
            date,
            total,
            status,
            paymentmethod: paymentMethod,
            duration: selectedDuration,
            roomprice: roomPrice,
            tax,
            client: [
                {
                    id: 1,
                    name,
                    email,
                    phone,
                    company: companyName,
                    address,
                    city,
                },
            ],
        };



        if (duration === 'multipledays') {
            bookingData.duration = selectedDays.join(','); // Update duration with selected days
        } else if (duration === 'halfday') {
            bookingData.duration = selectedHalfDay; // Update duration with selected half day
        } else if (duration === 'hours') {
            bookingData.duration = selectedHour; // Update duration with selected hour
        }

        createBooking(bookingData)
            .then(() => {
                console.log('Booking created successfully');
                NotificationManager.success('Booking Added Succesfully!');
                // Reset the form fields
                setRoomname('');
                setDate('');
                setTotal('');
                setStatus('');
                setPaymentMethod('');
                setDuration('');
                setRoomPrice('');
                setTax('');
                setName('');
                setEmail('');
                setPhone('');
                setCompanyName('');
                setAddress('');
                setCity('');

                // Navigate to Booking page
                navigate('/booking');
                refetch();

            })
            .catch((error) => {
                console.error('Error creating booking:', error);
            });
    };

    const handleDayButtonClick = (day, e) => {
        e.preventDefault();
        if (selectedDays.includes(day)) {
            setSelectedDays(selectedDays.filter((selectedDay) => selectedDay !== day));
        } else {
            setSelectedDays([...selectedDays, day]);
        }
        setDuration('multipledays'); // Update duration to 'multipledays'
    };


    const handleHalfDayButtonClick = (halfDay, e) => {
        e.preventDefault();
        setSelectedHalfDay(halfDay);
        setDuration('halfday'); // Update duration to 'halfday'
    };

    const handleHourButtonClick = (hour, e) => {
        e.preventDefault();
        setSelectedHour(hour);
        setDuration('hours'); // Update duration to 'hours'
    };

    // Calculate the minimum date (today onwards)
    const today = new Date();
    const minDate = today.toISOString().split('T')[0];

    return (
        <div className='container-fluid'>

            <div className='row'>
                <div className="col-2 sidebar">

                    <span className="side-mouse" onClick={() => navigate('/dashboard')}><i className="fa fa-clock-o p-2" aria-hidden="true"></i> <p className="p-1">Dashboard</p></span>
                    <span className="side-mouse" onClick={() => navigate('/booking')}><i className="fa fa-file-o p-2" aria-hidden="true"></i> <p className="p-1">Bookings</p></span>
                    <span className="side-mouse" onClick={() => navigate('/rooms')}><i className="fa fa-square-o p-2" aria-hidden="true"></i> <p className="p-1" >Rooms</p></span>
                    <span className="side-mouse" onClick={() => navigate('/admin-user')}><i className="fa fa-users p-2" aria-hidden="true"></i> <p className="p-1" >Users</p></span>
                    <span className="side-mouse" onClick={() => navigate('/')}><i className="fa fa-sign-out p-2" aria-hidden="true"></i> <p className="p-1" >Logout</p></span>
                </div>
                <div className="col-10">
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Booking</button>
                            <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Client</button>
                        </div>
                    </nav>
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                            <h2>Add Booking</h2>
                            <div className='container'>
                                <div className='row'>
                                    <div className='col-6'>
                                        <div className="mb-3">
                                            <label htmlFor="roomname" className="form-label">Room Name:</label>
                                            <select id="roomname" className="form-select" value={roomname} onChange={(e) => setRoomname(e.target.value)} required>
                                                <option value="">Select Room</option>
                                                <option value="Small Conference Room">Small Conference Room</option>
                                                <option value="Large  Conference Room">Large  Conference Room</option>
                                                <option value="Panoramic Room">Panoramic Room</option>
                                            </select>
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="date" className="form-label">Date:</label>
                                            <input type="date" id="date" className="form-control" value={date} min={minDate} onChange={(e) => setDate(e.target.value)} />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="roomPrice" className="form-label">Room Price:</label>
                                            <input type="text" id="roomPrice" className="form-control" value={roomPrice} onChange={(e) => setRoomPrice(e.target.value)} />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="total" className="form-label">Total:</label>
                                            <input type="text" id="total" className="form-control" value={total} onChange={(e) => setTotal(e.target.value)} />
                                        </div>
                                    </div>
                                    <div className='col-6'>
                                        <div className="mb-3">
                                            <label htmlFor="paymentMethod" className="form-label">Payment Method:</label>
                                            <select id="paymentMethod" className="form-select" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)} required>
                                                <option value="">Select Payment Method</option>
                                                <option value="Card">Card</option>
                                                <option value="Cash">Cash</option>
                                            </select>
                                        </div>

                                        <div className="mb-3">
                                            <label htmlFor="durationSelect" className="form-label">Duration</label>
                                            <select className="form-select" id="durationSelect" value={duration} onChange={(e) => setDuration(e.target.value)}>
                                                <option value="">Select Duration</option>
                                                <option value="multipledays">Multiple Days</option>
                                                <option value="halfday">Half Day</option>
                                                <option value="hours">Hours</option>
                                            </select>
                                        </div>
                                        {duration === 'multipledays' && (
                                            <div className="mb-3">
                                                <p>Select days:</p>
                                                <button
                                                    onClick={(e) => handleDayButtonClick('Monday', e)} className={selectedDays.includes('Monday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Monday</button>
                                                <button
                                                    onClick={(e) => handleDayButtonClick('Tuesday', e)}
                                                    className={selectedDays.includes('Tuesday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Tuesday</button>
                                                <button onClick={(e) => handleDayButtonClick('Wednesday', e)}
                                                    className={selectedDays.includes('Wednesday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Wednesday</button>
                                                <button onClick={(e) => handleDayButtonClick('Thursday', e)}
                                                    className={selectedDays.includes('Thursday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Thursday</button>
                                                <button onClick={(e) => handleDayButtonClick('Friday', e)}
                                                    className={selectedDays.includes('Friday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Friday</button>
                                                <button onClick={(e) => handleDayButtonClick('Saturday', e)}
                                                    className={selectedDays.includes('Saturday') ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Saturday</button>
                                            </div>
                                        )}
                                        {duration === 'halfday' && (
                                            <div className="mb-3">
                                                <p>Select half day:</p>
                                                <button onClick={(e) => handleHalfDayButtonClick('Morning', e)}
                                                    className={selectedHalfDay === 'Morning' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Morning (08:00-12:00)</button>
                                                <button onClick={(e) => handleHalfDayButtonClick('Afternoon', e)}
                                                    className={selectedHalfDay === 'Afternoon' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>Afternoon (13:00-16:00)</button>
                                                <button onClick={(e) => handleHalfDayButtonClick('Evening', e)}
                                                    className={selectedHalfDay === 'Evening' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'} >Evening (16:00-18:00)</button>
                                            </div>
                                        )}
                                        {duration === 'hours' && (
                                            <div className="mb-3">
                                                <p>Select hours:</p>
                                                <button onClick={(e) => handleHourButtonClick('09:00-10:00', e)}
                                                    className={selectedHour === '09:00-10:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>09:00-10:00</button>
                                                <button onClick={(e) => handleHourButtonClick('10:00-11:00', e)}
                                                    className={selectedHour === '10:00-11:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>10:00-11:00</button>
                                                <button onClick={(e) => handleHourButtonClick('11:00-12:00', e)}
                                                    className={selectedHour === '11:00-12:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>11:00-12:00</button>
                                                <button onClick={(e) => handleHourButtonClick('12:00-13:00', e)}
                                                    className={selectedHour === '12:00-13:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>12:00-13:00</button>
                                                <button onClick={(e) => handleHourButtonClick('13:00-14:00', e)}
                                                    className={selectedHour === '13:00-14:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>13:00-14:00</button>
                                                <button onClick={(e) => handleHourButtonClick('14:00-15:00', e)}
                                                    className={selectedHour === '14:00-15:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>14:00-15:00</button>
                                                <button onClick={(e) => handleHourButtonClick('15:00-16:00', e)}
                                                    className={selectedHour === '15:00-16:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>15:00-16:00</button>
                                                <button onClick={(e) => handleHourButtonClick('16:00-17:00', e)}
                                                    className={selectedHour === '16:00-17:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>16:00-17:00</button>
                                                <button onClick={(e) => handleHourButtonClick('17:00-18:00', e)}
                                                    className={selectedHour === '17:00-18:00' ? 'btn btn-primary m-2' : 'btn btn-secondary m-2'}>17:00-18:00</button>
                                            </div>
                                        )}
                                        <div className="mb-3">
                                            <label htmlFor="status" className="form-label">Status:</label>
                                            <select id="status" className="form-select" value={status} onChange={(e) => setStatus(e.target.value)} required>
                                                <option value="">Select Status</option>
                                                <option value="Pending">Pending</option>
                                                <option value="Confirmed">Confirmed</option>
                                                <option value="Cancelled">Cancelled</option>
                                            </select>
                                        </div>

                                        <div className="mb-3">
                                            <label htmlFor="tax" className="form-label">Tax:</label>
                                            <input type="text" id="tax" className="form-control" value={tax} onChange={(e) => setTax(e.target.value)} />
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <div className="mb-3">
                                <label htmlFor="name" className="form-label">Name:</label>
                                <input type="text" id="name" className="form-control" value={name} onChange={(e) => setName(e.target.value)} />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="email" className="form-label">Email:</label>
                                <input type="email" id="email" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="phone" className="form-label">Phone:</label>
                                <input type="text" id="phone" className="form-control" value={phone} onChange={(e) => setPhone(e.target.value)} />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="companyName" className="form-label">Company Name:</label>
                                <input type="text" id="companyName" className="form-control" value={companyName} onChange={(e) => setCompanyName(e.target.value)} />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="address" className="form-label">Address:</label>
                                <input type="text" id="address" className="form-control" value={address} onChange={(e) => setAddress(e.target.value)} />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="city" className="form-label">City:</label>
                                <input type="text" id="city" className="form-control" value={city} onChange={(e) => setCity(e.target.value)} />
                            </div>
                            <button type="submit" className="btn btn-primary" onClick={handleSaveBooking}>Save</button>
                        </div>
                    </div>
                </div>
            </div>

        </div >
    );
};

export default AddBooking;
