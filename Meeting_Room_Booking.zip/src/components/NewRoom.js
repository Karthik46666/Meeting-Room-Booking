import React, { useState } from 'react';
import { useGetRoomsQuery, useDeleteRoomMutation } from '../api';
import { useNavigate } from 'react-router-dom';
import { NotificationManager } from 'react-notifications';
import "../App.css";


const NewRoom = () => {
    const { data: rooms, isLoading, refetch } = useGetRoomsQuery();
    const [deleteRoom] = useDeleteRoomMutation();
    const navigate = useNavigate();
    const [filterStatus, setFilterStatus] = useState('all'); // 'all', 'active', 'inactive'
    const handleEditRoom = async (roomId) => {
        navigate(`/edit-room/${roomId}`);
        await refetch();
    };



    const handleDeleteRoom = async (id) => {
        try {
            console.log('Deleting room with id:', id);
            await deleteRoom(id).unwrap();
            NotificationManager.success('Deleted Room Succesfully!');
            refetch();
        } catch (error) {
            console.error('Error occurred during deletion:', error);
        }
    };

    const handleFilterChange = (status) => {
        setFilterStatus(status);
    };

    let filteredRooms = rooms;

    if (filterStatus === 'active') {
        filteredRooms = rooms.filter((room) => room.status === 'Active');
    } else if (filterStatus === 'inactive') {
        filteredRooms = rooms.filter((room) => room.status === 'Inactive');
    }

    if (isLoading) {
        return <div>Loading...</div>;
    }

    // if (isError) {
    //     return <div>Error occurred while fetching rooms.</div>;
    // }

    return (
        <div className='container-fluid'>

            <div className='row'>
                <div className="col-2 sidebar">

                    <span className="side-mouse" onClick={() => navigate('/dashboard')}><i className="fa fa-clock-o p-2" aria-hidden="true"></i> <p className="p-1">Dashboard</p></span>
                    <span className="side-mouse" onClick={() => navigate('/booking')}><i className="fa fa-file-o p-2" aria-hidden="true"></i> <p className="p-1">Bookings</p></span>
                    <span className="side-mouse" ><i className="fa fa-square-o p-2" aria-hidden="true"></i> <p className="p-1" >Rooms</p></span>
                    <span className="side-mouse" onClick={() => navigate('/admin-user')}><i className="fa fa-users p-2" aria-hidden="true"></i> <p className="p-1" >Users</p></span>
                    <span className="side-mouse" onClick={() => navigate('/')}><i className="fa fa-sign-out p-2" aria-hidden="true"></i> <p className="p-1" >Logout</p></span>
                </div>
                <div className="col-10 mt-3">
                    <h1>Rooms Details</h1>
                    <button className="btn btn-primary" onClick={() => navigate('/add-room')}>
                        Add Room
                    </button>
                    <button className="btn btn-secondary mx-2" onClick={() => handleFilterChange('all')}>
                        All
                    </button>
                    <button className="btn btn-success mx-2" onClick={() => handleFilterChange('active')}>
                        Active
                    </button>
                    <button className="btn btn-danger mx-2" onClick={() => handleFilterChange('inactive')}>
                        Inactive
                    </button>

                    {filteredRooms && filteredRooms.length > 0 ? (
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Room</th>
                                    <th>Capacity</th>
                                    <th>Booking</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredRooms.map((room) => (
                                    <tr key={room.id}>
                                        <td><img src={room.image} alt={room.room} style={{ width: 80 }} /></td>
                                        <td>{room.room}</td>
                                        <td>{room.capacity}</td>
                                        <td>{room.booking}</td>
                                        <td>{room.status}</td>
                                        <td>
                                            <span onClick={() => handleEditRoom(room.id)}><i class="fa fa-pencil p-2" aria-hidden="true"></i></span>
                                            <span onClick={() => handleDeleteRoom(room.id)}><i class="fa fa-trash" aria-hidden="true"></i></span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <div>No rooms found.</div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default NewRoom;
