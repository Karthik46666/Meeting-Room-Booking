import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGetUsersQuery } from '../api';

const User = () => {
    const navigate = useNavigate();
    const { data: users = [], isLoading } = useGetUsersQuery();
    const [searchQuery, setSearchQuery] = useState('');
    const filteredUsers = users.filter(
        (user) =>
            user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            user.email.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const handleSearch = (e) => {
        setSearchQuery(e.target.value);
    };

    if (isLoading) {
        return <div>Loading...</div>;
    }

    return (
        <div className='container-fluid'>

            <div className='row'>
                <div className="col-2 sidebar">

                    <span className="side-mouse" onClick={() => navigate('/dashboard')}><i className="fa fa-clock-o p-2" aria-hidden="true"></i> <p className="p-1">Dashboard</p></span>
                    <span className="side-mouse" onClick={() => navigate('/booking')}><i className="fa fa-file-o p-2" aria-hidden="true"></i> <p className="p-1">Bookings</p></span>
                    <span className="side-mouse" onClick={() => navigate('/rooms')}><i className="fa fa-square-o p-2" aria-hidden="true"></i> <p className="p-1" >Rooms</p></span>
                    <span className="side-mouse" ><i className="fa fa-users p-2" aria-hidden="true"></i> <p className="p-1" >Users</p></span>
                    <span className="side-mouse" onClick={() => navigate('/')}><i className="fa fa-sign-out p-2" aria-hidden="true"></i> <p className="p-1" >Logout</p></span>
                </div>
                <div className="col-10 mt-4">
                    <h2>User List Details</h2>
                    <div className="mb-3" style={{ float: 'right' }}>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search by name or email"
                            value={searchQuery}
                            onChange={handleSearch}
                        />
                    </div>
                    {filteredUsers.length === 0 ? (
                        <div style={{ display: 'flex', justifyContent: 'center' }}>No data found</div>
                    ) : (
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredUsers.map((user) => (
                                    <tr key={user.id}>
                                        <td>{user.name}</td>
                                        <td>{user.email}</td>
                                        <td>{user.role}</td>
                                        <td>{user.status}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>
        </div >
    );
};

export default User;
