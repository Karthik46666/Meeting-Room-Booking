import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const usersApi = createApi({
    reducerPath: 'usersApi',
    baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:3001' }),
    endpoints: (builder) => ({
        getUsers: builder.query({
            query: () => 'users',
        }),
        createUser: builder.mutation({
            query: (user) => ({
                url: 'users',
                method: 'POST',
                body: user,
            }),
        }),
    }),
});

export const roomsApi = createApi({
    reducerPath: 'roomsApi',
    baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:3001' }),
    endpoints: (builder) => ({
        getRooms: builder.query({
            query: () => 'rooms',
        }),
        updateRoom: builder.mutation({
            query: ({ id, ...room }) => ({
                url: `rooms/${id}`,
                method: 'PUT',
                body: room,
            }),
        }),
        deleteRoom: builder.mutation({
            query: (roomId) => ({
                url: `rooms/${roomId}`,
                method: 'DELETE',
            }),
        }),
        createRoom: builder.mutation({
            query: (newRoom) => ({
                url: 'rooms',
                method: 'POST',
                body: newRoom,
            }),
        }),
    }),
});

export const bookingApi = createApi({
    reducerPath: 'bookingApi',
    baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:3001' }),
    endpoints: (builder) => ({
        getBookings: builder.query({
            query: () => 'bookings',
        }),
        createBooking: builder.mutation({
            query: (booking) => ({
                url: 'bookings',
                method: 'POST',
                body: booking,
            }),
        }),
        getBookingById: builder.query({
            query: (id) => `bookings/${id}`,
        }),
        updateBooking: builder.mutation({
            query: ({ id, ...booking }) => ({
                url: `bookings/${id}`,
                method: 'PUT',
                body: booking,
            }),
        }),
        deleteBooking: builder.mutation({
            query: (id) => ({
                url: `bookings/${id}`,
                method: 'DELETE',
            }),
        }),
    }),
});

export const clientApi = createApi({
    reducerPath: 'clientApi',
    baseQuery: fetchBaseQuery({ baseUrl: 'http://localhost:3001' }),
    endpoints: (builder) => ({
        createClient: builder.mutation({
            query: (client) => ({
                url: 'client',
                method: 'POST',
                body: client,
            }),
        }),
    }),
});

export const { useGetUsersQuery, useCreateUserMutation } = usersApi;
export const { useGetRoomsQuery, useUpdateRoomMutation, useDeleteRoomMutation, useCreateRoomMutation } = roomsApi;
export const { useGetBookingsQuery, useCreateBookingMutation, useGetBookingByIdQuery, useUpdateBookingMutation, useDeleteBookingMutation } = bookingApi;
export const { useCreateClientMutation } = clientApi;