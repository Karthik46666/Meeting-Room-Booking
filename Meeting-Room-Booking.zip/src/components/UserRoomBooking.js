import React from 'react';
import { useParams } from 'react-router-dom';
import { useGetRoomsQuery } from '../api';
import "../App.css";

const UserRoomBooking = () => {
    const { roomId } = useParams();
    const { data: rooms = [], isLoading } = useGetRoomsQuery();

    if (isLoading) {
        return <div>Loading...</div>;
    }

    const room = rooms.find((room) => room.id === parseInt(roomId));

    if (!room) {
        return <div>Room not found</div>;
    }

    return (
        <div className='container-fluid p-0'>
            <div className="header">
                <p className="fs-2">Meeting rooms</p>
            </div>
            <div className="card m-5 p-4">
                <h2>User Room Booking</h2>
                <div>
                    <img src={room.image} alt={room.room} />
                    <p>Room: {room.room}</p>
                    <p>Capacity: {room.capacity}</p>
                    <p>Price per Day: {room.priceperday}</p>
                    <p>Price per Hour: {room.priceperhour}</p>
                </div>
            </div>
        </div>
    );
};

export default UserRoomBooking;
