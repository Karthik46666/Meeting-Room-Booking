import React from 'react';

const UserLanding = () => {
    return (
        <div>
            <h2>Welcome to the User Module Page!</h2>
            {/* Add your user landing page content here */}
        </div>
    );
};

export default UserLanding;
