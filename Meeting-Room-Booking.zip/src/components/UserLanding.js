import React from 'react';
import { Link, useNavigate } from "react-router-dom";
import { useGetRoomsQuery } from '../api';
import { useLocation } from 'react-router-dom';
const UserLanding = () => {
    const { data: rooms = [], isLoading } = useGetRoomsQuery();
    const location = useLocation();
    const { user } = location.state || {};
    const navigate = useNavigate();

    if (!user) {
        // Handle case when user information is not available
        return <div>No user information found</div>;
    }
    if (isLoading) {
        return <div>Loading...</div>;
    }

    const handleBookRoom = (roomId) => {
        navigate(`/user-room-booking/${roomId}`);
    };


    return (
        <div className='container-fluid p-0'>
            <div className="header">
                <p className="fs-2 mb-0 fw-bold">Meeting rooms</p>
                <p className="fs-4 mb-0 fw-bold" style={{ marginLeft: "50rem" }}>Welcome,{user.name}</p>
                <Link to="/" className="d-flex align-items-center  px-0 text-dark text-decoration-none fs-5 fw-bold">
                    <i className="fa fa-sign-out"></i> <span className="ms-3 d-none d-sm-inline">Logout</span>
                </Link>
            </div>
            {rooms.map((room) => (

                <div className="card m-5 p-4" key={room.id}>
                    <div className="row">
                        <div className="col-6">
                            <img src={room.image} alt="" width={"500px"}></img>
                            <div className="row">
                                <div className="col">
                                    <p className="mt-3 mb-0">Capacity:</p>
                                    <p style={{ fontWeight: "bold" }}>{room.capacity} people</p>
                                </div>
                                <div className="col">
                                    <p className="mt-3 mb-0">Price:</p>
                                    <p style={{ fontWeight: "bold" }} className="mb-0">$ {room.priceperday} per day</p>
                                    <p style={{ fontWeight: "bold" }} className="mb-0">$ {room.priceperhour} per hour</p>


                                </div>
                            </div>
                        </div>
                        <div className="col-6">
                            <h2 style={{ color: "black", fontSize: "2rem", fontWeight: "bold" }}>{room.room}</h2>
                            <p>{room.description}</p>
                            <button type="button" className="btn btn-primary btn-lg" onClick={() => handleBookRoom(room.id)}>Book this room</button>
                        </div>
                    </div>
                </div>

            ))}
        </div>
    );
};

export default UserLanding;
