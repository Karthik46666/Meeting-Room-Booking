import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGetUsersQuery, useCreateUserMutation } from '../api';
import { NotificationManager } from 'react-notifications';

const Signup = () => {
    const navigate = useNavigate();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('');
    const [status, setStatus] = useState('');
    const { refetch } = useGetUsersQuery();
    const [createUser] = useCreateUserMutation();

    const handleSave = async () => {
        try {
            const newUser = {
                email: email,
                password,
                name,
                role,
                status,
            };
            await createUser(newUser);
            NotificationManager.success('Account Created Successfully');
            navigate('/');
            refetch();
        } catch (error) {
            console.log(error);
        }
    };

    return (
        <div className="container signupcard">
            <h2>Signup</h2>

            <div className="mb-3">
                <label htmlFor="name" className="form-label">
                    Name
                </label>
                <input type="text" className="form-control" id="name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="mb-3">
                <label htmlFor="email" className="form-label">
                    Email
                </label>
                <input type="email" className="form-control" id="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="mb-3">
                <label htmlFor="password" className="form-label">
                    Password
                </label>
                <input
                    type="password"
                    className="form-control"
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
            </div>
            <div className="mb-3">
                <label htmlFor="role" className="form-label">
                    Role
                </label>
                <input type="text" className="form-control" id="role" value={role} onChange={(e) => setRole(e.target.value)} />
            </div>
            <div className="mb-3">
                <label htmlFor="status" className="form-label">
                    Status
                </label>
                <input type="text" className="form-control" id="status" value={status} onChange={(e) => setStatus(e.target.value)} />
            </div>
            <button type="button" className="btn btn-primary" onClick={handleSave}>
                Save
            </button>
        </div>
    );
};

export default Signup;
