import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGetBookingsQuery, useDeleteBookingMutation } from '../api';
import { NotificationManager } from 'react-notifications';

const Bookings = () => {
    const navigate = useNavigate();
    const { data: bookings = [], isLoading, isError, refetch } = useGetBookingsQuery();
    const [deleteBooking] = useDeleteBookingMutation();
    const [searchQuery, setSearchQuery] = useState('');
    const filteredUsers = bookings.filter(
        (user) =>
            user.roomname.toLowerCase().includes(searchQuery.toLowerCase()) ||
            user.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const handleSearch = (e) => {
        setSearchQuery(e.target.value);
    };

    if (isLoading) {
        return <div>Loading...</div>;
    }

    if (isError) {
        return <div>Error occurred while fetching bookings.</div>;
    }

    const handleEditBooking = (bookingId) => {
        navigate(`/edit-bookings/${bookingId}`);
    };
    const handleDelete = async (bookingId) => {
        // Delete the booking
        await deleteBooking(bookingId).unwrap();
        NotificationManager.success('Deleted Booking Successfully');
        refetch();
    };

    return (
        <div className='container-fluid'>

            <div className='row'>
                <div className="col-2 sidebar">

                    <span className="side-mouse" onClick={() => navigate('/dashboard')}><i className="fa fa-clock-o p-2" aria-hidden="true"></i> <p className="p-1">Dashboard</p></span>
                    <span className="side-mouse" onClick={() => navigate('/booking')}><i className="fa fa-file-o p-2" aria-hidden="true"></i> <p className="p-1">Bookings</p></span>
                    <span className="side-mouse" onClick={() => navigate('/rooms')}><i className="fa fa-square-o p-2" aria-hidden="true"></i> <p className="p-1" >Rooms</p></span>
                    <span className="side-mouse" onClick={() => navigate('/admin-user')}><i className="fa fa-users p-2" aria-hidden="true"></i> <p className="p-1" >Users</p></span>
                    <span className="side-mouse" onClick={() => navigate('/')}><i className="fa fa-sign-out p-2" aria-hidden="true"></i> <p className="p-1" >Logout</p></span>
                </div>
                <div className="col-10 mt-3">
                    <h1>Bookings</h1>
                    <button className="btn btn-primary" onClick={() => navigate('/add-booking')}>Add Bookings</button>
                    <div className="mb-3" style={{ float: 'right' }}>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search roomname or name"
                            value={searchQuery}
                            onChange={handleSearch}
                        />
                    </div>
                    {filteredUsers.length === 0 ? (
                        <div style={{ display: 'flex', justifyContent: 'center' }}>No data found</div>
                    ) : (
                        <table className="table table-striped">
                            <thead>
                                <tr>
                                    <th>Room Name</th>
                                    <th>Date</th>
                                    <th>Name</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredUsers.map((booking) => (
                                    <tr key={booking.id}>
                                        <td>{booking.roomname}</td>
                                        <td>{booking.date}</td>
                                        <td>{booking.name}</td>
                                        <td>{booking.total}</td>
                                        <td>{booking.status}</td>

                                        <td>
                                            <span onClick={() => handleEditBooking(booking.id)}><i class="fa fa-pencil p-2" aria-hidden="true"></i></span>
                                            <span onClick={() => handleDelete(booking.id)}><i class="fa fa-trash" aria-hidden="true"></i></span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Bookings;
