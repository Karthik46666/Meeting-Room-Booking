import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCreateRoomMutation, useGetRoomsQuery } from '../api';
import { NotificationManager } from 'react-notifications';

const AddRoom = () => {
    const navigate = useNavigate();
    const [roomData, setRoomData] = useState({
        room: '',
        capacity: '',
        booking: '',
        status: '',
        description: '',
        priceperday: '',
        priceperhour: '',
    });

    const [createRoom] = useCreateRoomMutation();
    const { refetch } = useGetRoomsQuery();
    const handleSave = async () => {
        try {
            await createRoom(roomData).unwrap();
            NotificationManager.success('Added Room Succesfully!');
            navigate('/rooms');
            refetch();
        } catch (error) {
            console.log(error);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setRoomData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    return (
        <div className='container-fluid'>

            <div className='row'>
                <div className="col-2 sidebar">

                    <span className="side-mouse" onClick={() => navigate('/dashboard')}><i className="fa fa-clock-o p-2" aria-hidden="true"></i> <p className="p-1">Dashboard</p></span>
                    <span className="side-mouse" onClick={() => navigate('/booking')}><i className="fa fa-file-o p-2" aria-hidden="true"></i> <p className="p-1">Bookings</p></span>
                    <span className="side-mouse" onClick={() => navigate('/rooms')}><i className="fa fa-square-o p-2" aria-hidden="true"></i> <p className="p-1" >Rooms</p></span>
                    <span className="side-mouse" onClick={() => navigate('/admin-user')}><i className="fa fa-users p-2" aria-hidden="true"></i> <p className="p-1" >Users</p></span>
                    <span className="side-mouse" onClick={() => navigate('/')}><i className="fa fa-sign-out p-2" aria-hidden="true"></i> <p className="p-1" >Logout</p></span>
                </div>
                <div className="col-10">
                    <div className='container mt-3'>
                        <h2>Add Room</h2>
                        <form>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Room:</label>
                                <input type="text" className="form-control" id="room" name="room" value={roomData.room} onChange={handleChange} />
                            </div>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Capacity:</label>
                                <input type="text" className="form-control" id="capacity" name="capacity" value={roomData.capacity} onChange={handleChange} />
                            </div>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Booking:</label>
                                <input type="text" className="form-control" id="booking" name="booking" value={roomData.booking} onChange={handleChange} />
                            </div>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Status:</label>
                                <input type="text" className="form-control" id="status" name="status" value={roomData.status} onChange={handleChange} />
                            </div>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Price Per Day:</label>
                                <input type="text" className="form-control" id="priceperday" name="priceperday" value={roomData.priceperday} onChange={handleChange} />
                            </div>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Price Per Hour:</label>
                                <input type="text" className="form-control" id="priceperhour" name="priceperhour" value={roomData.priceperhour} onChange={handleChange} />
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Description</label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="description" value={roomData.description} onChange={handleChange}></textarea>
                            </div>
                            <button type="button" class="btn btn-primary m-2" onClick={handleSave}>
                                Save
                            </button>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddRoom;
