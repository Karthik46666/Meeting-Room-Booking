import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useGetRoomsQuery, useUpdateRoomMutation } from '../api';
import { NotificationManager } from 'react-notifications';

const EditRoom = () => {
    const { roomId } = useParams();
    const { data: rooms, isLoading, isError, refetch } = useGetRoomsQuery();
    const [updateRoom, { isLoading: isUpdating }] = useUpdateRoomMutation();
    const navigate = useNavigate();

    const [image, setImage] = useState('');
    const [roomName, setRoomName] = useState('');
    const [capacity, setCapacity] = useState('');
    const [booking, setBooking] = useState('');
    const [status, setStatus] = useState('');



    useEffect(() => {
        if (rooms) {
            const room = rooms.find((room) => room.id === Number(roomId));
            if (room) {
                setImage(room.image);
                setRoomName(room.room);
                setCapacity(room.capacity);
                setBooking(room.booking);
                setStatus(room.status);
            }
        }
    }, [roomId, rooms]);

    if (isLoading) {
        return <div>Loading...</div>;
    }

    if (isError) {
        return <div>Error occurred while fetching room details.</div>;
    }


    const handleUpdateRoom = async (e) => {
        e.preventDefault();
        const updatedRoom = {
            id: Number(roomId),
            image,
            room: roomName,
            capacity,
            booking,
            status,
        };
        await updateRoom(updatedRoom);
        NotificationManager.success('Updated Room Succesfully!');
        navigate('/rooms');
        refetch();

        // Handle the update logic here
        // You can make an API call or update the data using other methods
    };

    return (
        <div className='container-fluid'>

            <div className='row'>
                <div className="col-2 sidebar">

                    <span className="side-mouse" onClick={() => navigate('/dashboard')}><i className="fa fa-clock-o p-2" aria-hidden="true"></i> <p className="p-1">Dashboard</p></span>
                    <span className="side-mouse" onClick={() => navigate('/booking')}><i className="fa fa-file-o p-2" aria-hidden="true"></i> <p className="p-1">Bookings</p></span>
                    <span className="side-mouse" onClick={() => navigate('/rooms')}><i className="fa fa-square-o p-2" aria-hidden="true"></i> <p className="p-1" >Rooms</p></span>
                </div>
                <div className="col-10">
                    <h2>Edit Room</h2>
                    {isLoading && <p>Loading...</p>}
                    {isError && <p>Error occurred while fetching room details.</p>}
                    {rooms && (
                        <form onSubmit={handleUpdateRoom}>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Image:</label>
                                <input
                                    className="form-control"
                                    type="text"
                                    id="image"
                                    value={image}
                                    onChange={(e) => setImage(e.target.value)}
                                />
                            </div>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Room Name:</label>
                                <input
                                    className="form-control"
                                    type="text"
                                    id="roomName"
                                    value={roomName}
                                    onChange={(e) => setRoomName(e.target.value)}
                                />
                            </div>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Capacity:</label>
                                <input
                                    className="form-control"
                                    type="text"
                                    id="capacity"
                                    value={capacity}
                                    onChange={(e) => setCapacity(e.target.value)}
                                />
                            </div>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Booking:</label>
                                <input
                                    className="form-control"
                                    type="text"
                                    id="booking"
                                    value={booking}
                                    onChange={(e) => setBooking(e.target.value)}
                                />
                            </div>
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Status:</label>
                                <input
                                    className="form-control"
                                    type="text"
                                    id="status"
                                    value={status}
                                    onChange={(e) => setStatus(e.target.value)}
                                />
                            </div>
                            <button type="submit" class="btn btn-primary m-2" disabled={isUpdating}>
                                Update
                            </button>
                        </form>
                    )}
                </div>
            </div>
        </div>
    );
};

export default EditRoom;
