import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { NotificationManager } from 'react-notifications';
import { useCreateBookingMutation, useGetBookingsQuery, useCreateClientMutation } from '../api';

const AddBooking = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        status: '',
        paymentMethod: '',
        roomname: '',
        duration: '',
        roomPrice: '',
        tax: '',
        total: '',
        name: '',
    });


    const [createBookingMutation] = useCreateBookingMutation();
    const { refetch } = useGetBookingsQuery();
    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSave = async (event) => {
        event.preventDefault();

        try {
            await createBookingMutation(formData).unwrap();
            await refetch();
            NotificationManager.success('Added Booking Successfully');
            navigate('/booking');
        } catch (error) {
            console.log(error);
        }
    };

    // Get the current date
    const currentDate = new Date().toISOString().split('T')[0];

    //code start for client details
    const [clientFormData, setClientFormData] = useState({
        name: '',
        email: '',
        phone: '',
        companyName: '',
        address: '',
        city: '',
    });
    const { name, email, phone, companyName, address, city } = clientFormData;
    const [createClient, { isLoading, isError }] = useCreateClientMutation();

    const handleClientInputChange = (e) => {
        setClientFormData({ ...clientFormData, [e.target.name]: e.target.value });
    };

    const handleClientSubmit = async (e) => {
        e.preventDefault();
        try {
            await createClient(clientFormData);
            setClientFormData({
                name: '',
                email: '',
                phone: '',
                companyName: '',
                address: '',
                city: '',
            });
            NotificationManager.success('Client Added Successfully');
            navigate('/booking');
            // Refresh or fetch the updated data after successful submission
            // You can use the appropriate query or refetch method based on your implementation
            // Example: refetch();
        } catch (error) {
            console.log(error);
        }
    };

    return (
        <>
            <div className='container-fluid'>

                <div className='row'>
                    <div className="col-2 sidebar">

                        <span className="side-mouse" onClick={() => navigate('/dashboard')}><i className="fa fa-clock-o p-2" aria-hidden="true"></i> <p className="p-1">Dashboard</p></span>
                        <span className="side-mouse" onClick={() => navigate('/booking')}><i className="fa fa-file-o p-2" aria-hidden="true"></i> <p className="p-1">Bookings</p></span>
                        <span className="side-mouse" onClick={() => navigate('/rooms')}><i className="fa fa-square-o p-2" aria-hidden="true"></i> <p className="p-1" >Rooms</p></span>
                        <span className="side-mouse" onClick={() => navigate('/admin-user')}><i className="fa fa-users p-2" aria-hidden="true"></i> <p className="p-1" >Users</p></span>
                        <span className="side-mouse" onClick={() => navigate('/')}><i className="fa fa-sign-out p-2" aria-hidden="true"></i> <p className="p-1" >Logout</p></span>
                    </div>
                    <div className="col-10">
                        <nav>
                            <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Booking</button>
                                <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Client</button>
                            </div>
                        </nav>
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                                <h1>Add Booking</h1>
                                <div className='container'>
                                    <div className='row'>
                                        <form onSubmit={handleSave}>
                                            <div className='row'>
                                                <div className='col-6'>
                                                    <div className="mb-3">
                                                        <label htmlFor="name" className="form-label">
                                                            Name
                                                        </label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="name"
                                                            name="name"
                                                            value={formData.name}
                                                            onChange={handleInputChange}
                                                        />
                                                    </div>
                                                    <div className="mb-3">
                                                        <label htmlFor="date" className="form-label">Date</label>
                                                        <input
                                                            type="date"
                                                            className="form-control"
                                                            id="date"
                                                            name="date"
                                                            min={currentDate}
                                                            onChange={handleInputChange}
                                                            required
                                                        />
                                                    </div>



                                                    <div className="mb-3">
                                                        <label htmlFor="roomPrice" className="form-label">
                                                            Room Price
                                                        </label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="roomPrice"
                                                            name="roomPrice"
                                                            value={formData.roomPrice}
                                                            onChange={handleInputChange}
                                                        />
                                                    </div>
                                                    <div className="mb-3">
                                                        <label htmlFor="tax" className="form-label">
                                                            Tax
                                                        </label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="tax"
                                                            name="tax"
                                                            value={formData.tax}
                                                            onChange={handleInputChange}
                                                        />
                                                    </div>
                                                    <div className="mb-3">
                                                        <label htmlFor="total" className="form-label">
                                                            Total
                                                        </label>
                                                        <input
                                                            type="text"
                                                            className="form-control"
                                                            id="total"
                                                            name="total"
                                                            value={formData.total}
                                                            onChange={handleInputChange}
                                                        />
                                                    </div>
                                                </div>
                                                <div className='col-6'>
                                                    <div className="mb-3">
                                                        <label htmlFor="duration" className="form-label">
                                                            Duration
                                                        </label>
                                                        <select
                                                            className="form-select"
                                                            id="duration"
                                                            name="duration"
                                                            value={formData.duration}
                                                            onChange={handleInputChange}
                                                        >
                                                            <option value="morning">Morning</option>
                                                            <option value="afternoon">Afternoon</option>
                                                        </select>
                                                    </div>
                                                    <div className="mb-3">
                                                        <label htmlFor="status" className="form-label">
                                                            Status
                                                        </label>
                                                        <select
                                                            className="form-select"
                                                            id="status"
                                                            name="status"
                                                            value={formData.status}
                                                            onChange={handleInputChange}
                                                        >
                                                            <option value="Active">Active</option>
                                                            <option value="InActive">InActive</option>
                                                        </select>
                                                    </div>
                                                    <div className="mb-3">
                                                        <label htmlFor="paymentMethod" className="form-label">
                                                            Payment Method
                                                        </label>
                                                        <select
                                                            className="form-select"
                                                            id="paymentMethod"
                                                            name="paymentMethod"
                                                            value={formData.paymentMethod}
                                                            onChange={handleInputChange}
                                                        >
                                                            <option value="cash">Cash</option>
                                                            <option value="card">Card</option>
                                                        </select>
                                                    </div>
                                                    <div className="mb-3">
                                                        <label htmlFor="roomname" className="form-label">
                                                            Room
                                                        </label>
                                                        <select
                                                            className="form-select"
                                                            id="roomname"
                                                            name="roomname"
                                                            value={formData.roomname}
                                                            onChange={handleInputChange}
                                                        >
                                                            <option value="Small Conference Room">Small Conference Room</option>
                                                            <option value="Large Conference Room">Large Conference Room</option>
                                                            <option value="Panoramic Room">Panoramic Room</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>


                                            <button type="submit" className="btn btn-primary">Save</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">

                                {/* //Client details here --> */}
                                <div className="container">
                                    <h1 className="mt-2">Add Client</h1>
                                    <form onSubmit={handleClientSubmit}>
                                        <div className="form-group mb-3">
                                            <label htmlFor="name" className="form-label">
                                                Name
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="name"
                                                name="name"
                                                value={name}
                                                onChange={handleClientInputChange}
                                            />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="email" className="form-label">
                                                Email
                                            </label>
                                            <input
                                                type="email"
                                                className="form-control"
                                                id="email"
                                                name="email"
                                                value={email}
                                                onChange={handleClientInputChange}
                                            />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="phone" className="form-label">
                                                Phone
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="phone"
                                                name="phone"
                                                value={phone}
                                                onChange={handleClientInputChange}
                                            />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="companyName" className="form-label">
                                                Company Name
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="companyName"
                                                name="companyName"
                                                value={companyName}
                                                onChange={handleClientInputChange}
                                            />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="address" className="form-label">
                                                Address
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="address"
                                                name="address"
                                                value={address}
                                                onChange={handleClientInputChange}
                                            />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="city" className="form-label">
                                                City
                                            </label>
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="city"
                                                name="city"
                                                value={city}
                                                onChange={handleClientInputChange}
                                            />
                                        </div>
                                        <button type="submit" className="btn btn-primary">
                                            Save
                                        </button>
                                    </form>
                                    {isLoading && <div>Loading...</div>}
                                    {isError && <div>Error occurred while creating client.</div>}
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AddBooking;
