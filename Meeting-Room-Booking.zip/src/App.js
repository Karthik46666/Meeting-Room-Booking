import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import UserLanding from './components/UserLanding';
import NewRoom from './components/NewRoom';
import EditRoom from './components/EditRoom';
import AddRoom from './components/AddRoom';
import Bookings from './components/Bookings';
import AddBooking from './components/AddBooking';
import EditBooking from './components/EditBooking';
import Signup from './components/Signup';
import User from "./components/User";
import { NotificationContainer } from 'react-notifications';
import 'react-notifications/lib/notifications.css';


const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/sign-up" element={<Signup />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/user" element={<UserLanding />} />
        <Route path="/rooms" element={<NewRoom />} />
        <Route path="/edit-room/:roomId" element={<EditRoom />} />
        <Route path="/add-room" element={<AddRoom />} />
        <Route path="/booking" element={<Bookings />} />
        <Route path="/add-booking" element={<AddBooking />} />
        <Route path="/edit-bookings/:bookingId" element={<EditBooking />} />
        <Route path="/admin-user" element={<User />} />
      </Routes>
      <NotificationContainer />
    </Router>
  );
};

export default App;
