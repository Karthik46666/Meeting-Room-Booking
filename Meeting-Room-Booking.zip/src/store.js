import { configureStore } from '@reduxjs/toolkit';
import { setupListeners } from '@reduxjs/toolkit/query/react';
import { usersApi, roomsApi, bookingApi, clientApi } from './api';

const store = configureStore({
    reducer: {
        [usersApi.reducerPath]: usersApi.reducer,
        [roomsApi.reducerPath]: roomsApi.reducer,
        [bookingApi.reducerPath]: bookingApi.reducer,
        [clientApi.reducerPath]: clientApi.reducer,

    },
    middleware: (getDefaultMiddleware) =>
        getDefaultMiddleware().concat(usersApi.middleware).concat(roomsApi.middleware).concat(bookingApi.middleware).concat(clientApi.middleware),
});

setupListeners(store.dispatch);

export { store };
